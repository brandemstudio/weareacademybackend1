// Plain Node test script (no framework needed) for the booking engine.
// Run with: node test/booking.test.js
const assert = require('assert');
const path = require('path');
const fs = require('fs');

// Point db.js at a throwaway data directory so this never touches real data.
const TEST_DATA_DIR = path.join(__dirname, '.test-data');
process.env.ACADEMY_DATA_DIR = TEST_DATA_DIR;

function freshData() {
  fs.rmSync(TEST_DATA_DIR, { recursive: true, force: true });
  fs.mkdirSync(TEST_DATA_DIR, { recursive: true });
}

function loadFreshEngine() {
  delete require.cache[require.resolve('../db')];
  delete require.cache[require.resolve('../booking-engine')];
  return require('../booking-engine');
}

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); console.log(`  ok - ${name}`); passed++; }
  catch (e) { console.log(`  FAIL - ${name}\n    ${e.message}`); failed++; }
}

// ---------------------------------------------------------------
freshData();
let engine = loadFreshEngine();
const db = require('../db');

db.insert('sessions', {
  id: 'sess1', date: '2026-09-01', startTime: '10:00am', endTime: '11:00am',
  locationId: 'london', instructorId: 'instr1', sessionType: 'private',
  capacity: 3, price: 50, status: 'active',
});

test('books successfully when space available', () => {
  const b = engine.bookSession({ sessionId: 'sess1', studentId: 'stu1', parentId: 'par1' });
  assert.strictEqual(b.status, 'booked');
  assert.strictEqual(engine.spacesRemaining(db.findOne('sessions', s => s.id === 'sess1')), 2);
});

test('same student cannot double-book the same session', () => {
  assert.throws(() => engine.bookSession({ sessionId: 'sess1', studentId: 'stu1', parentId: 'par1' }),
    /already booked|already_booked/i);
});

test('fills to exactly capacity and then rejects the 4th booking', () => {
  engine.bookSession({ sessionId: 'sess1', studentId: 'stu2', parentId: 'par2' });
  engine.bookSession({ sessionId: 'sess1', studentId: 'stu3', parentId: 'par3' });
  const session = db.findOne('sessions', s => s.id === 'sess1');
  assert.strictEqual(engine.spacesRemaining(session), 0);
  assert.throws(() => engine.bookSession({ sessionId: 'sess1', studentId: 'stu4', parentId: 'par4' }),
    /full/i);
});

test('cancelling outside the 7-day window applies no fee', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's2', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'london', instructorId: 'i1', sessionType: 'private', capacity: 3, price: 50, status: 'active' });
  const b = engine.bookSession({ sessionId: 's2', studentId: 'stuA', parentId: 'parA' });
  const farInAdvance = new Date('2026-11-01'); // 30 days before the session
  const result = engine.cancelBooking({ bookingId: b.id, reason: 'clash', actorRole: 'parent' }, farInAdvance);
  assert.strictEqual(result.feeApplies, false);
  const updated = db.findOne('bookings', x => x.id === b.id);
  assert.strictEqual(updated.status, 'cancelled');
  assert.strictEqual(updated.cancellationFeeApplied, false);
});

test('cancelling within the 7-day window applies the fee', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's3', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'london', instructorId: 'i1', sessionType: 'private', capacity: 3, price: 50, status: 'active' });
  const b = engine.bookSession({ sessionId: 's3', studentId: 'stuB', parentId: 'parB' });
  const lastMinute = new Date('2026-11-28'); // 3 days before
  const result = engine.cancelBooking({ bookingId: b.id, reason: 'ill', actorRole: 'parent' }, lastMinute);
  assert.strictEqual(result.feeApplies, true);
  const updated = db.findOne('bookings', x => x.id === b.id);
  assert.strictEqual(updated.cancellationFeeApplied, true);
});

test('admin cancellation overrides the fee even within the window', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's4', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'london', instructorId: 'i1', sessionType: 'private', capacity: 3, price: 50, status: 'active' });
  const b = engine.bookSession({ sessionId: 's4', studentId: 'stuC', parentId: 'parC' });
  const result = engine.cancelBooking({ bookingId: b.id, reason: 'admin waived', actorRole: 'admin' }, new Date('2026-11-30'));
  assert.strictEqual(result.feeApplies, false);
});

test('educational (mandatory) sessions are never charged a cancellation fee', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's5', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'london', instructorId: 'i1', sessionType: 'educational', capacity: 30, price: 0, status: 'active' });
  const b = engine.bookSession({ sessionId: 's5', studentId: 'stuD', parentId: 'parD' });
  const result = engine.cancelBooking({ bookingId: b.id, reason: null, actorRole: 'parent' }, new Date('2026-11-30'));
  assert.strictEqual(result.feeApplies, false);
});

test('waitlist: joining a full session and releasing a slot notifies the waiter', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's6', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'stevenage', instructorId: 'i1', sessionType: 'private', capacity: 1, price: 50, status: 'active' });
  const first = engine.bookSession({ sessionId: 's6', studentId: 'stuE', parentId: 'parE' });
  engine.joinWaitlist({ sessionId: 's6', studentId: 'stuF', parentId: 'parF' });

  // No notification yet — session is still full.
  assert.strictEqual(db.find('notifications', n => n.userId === 'parF').length, 0);

  engine.releaseBooking({ bookingId: first.id });

  const notifs = db.find('notifications', n => n.userId === 'parF');
  assert.strictEqual(notifs.length, 1);
  assert.strictEqual(notifs[0].type, 'space_available');

  // The freed space is genuinely bookable again.
  const second = engine.bookSession({ sessionId: 's6', studentId: 'stuF', parentId: 'parF' });
  assert.strictEqual(second.status, 'booked');
});

test('released slot cannot be double-taken once someone else books it', () => {
  freshData(); engine = loadFreshEngine();
  db.insert('sessions', { id: 's7', date: '2026-12-01', startTime: '10:00am', endTime: '11:00am', locationId: 'stevenage', instructorId: 'i1', sessionType: 'private', capacity: 1, price: 50, status: 'active' });
  const first = engine.bookSession({ sessionId: 's7', studentId: 'stuG', parentId: 'parG' });
  engine.releaseBooking({ bookingId: first.id });
  engine.bookSession({ sessionId: 's7', studentId: 'stuH', parentId: 'parH' });
  assert.throws(() => engine.bookSession({ sessionId: 's7', studentId: 'stuI', parentId: 'parI' }), /full/i);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
